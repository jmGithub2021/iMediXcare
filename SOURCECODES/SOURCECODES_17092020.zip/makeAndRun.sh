# for DDP Machine
cd ~/iMediX/SOURCECODES/server_module_source_code
./makeJar.sh
cd ~/iMediX/SOURCECODES/tomcat_module_source_code/WEB-INF/classes/src
./makeJar.sh
sudo killall -9 java
cd ~/iMediX/Tomcat7/bin
sudo ./shutdown.sh
sudo ./startup.sh
cd ~/iMediX/iMediX-BL
sudo ./RunServer.sh
