cp -r /home/surajit/iMediX/SOURCECODES/server_module_source_code/imedix `pwd`

/home/surajit/iMediX/jdk8/bin/javac -d `pwd` *.java

/home/surajit/iMediX/jdk8/bin/javac -d `pwd`/src_servlet *.java
cp -r `pwd`/src_servlet/imedixservlets/* `pwd`/imedixservlets

/home/surajit/iMediX/jdk8/bin/jar -cf  imedix.jar imedix/*.class
/home/surajit/iMediX/jdk8/bin/jar -cf  tuberculosis.jar tuberculosis/*.class
/home/surajit/iMediX/jdk8/bin/jar -cf  phiv.jar phiv/*.class
/home/surajit/iMediX/jdk8/bin/jar -cf  onlinegc.jar onlinegc/*.class
/home/surajit/iMediX/jdk8/bin/jar -cf  logger.jar logger/*.class
/home/surajit/iMediX/jdk8/bin/jar -cf  imedixservlets.jar imedixservlets/*.class
cp -r *.jar /home/surajit/iMediX/Tomcat7/webapps/iMediX/WEB-INF/lib

echo done
