cjpeg must be installed in ubuntu machine
